#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "funciones.h"

void guardarPaciente(struct Paciente paciente, FILE *archivo) {
    fprintf(archivo, "ID: %d\n", paciente.id);
    fprintf(archivo, "Nombre: %s\n", paciente.nombre);
    fprintf(archivo, "Dirección: %s\n", paciente.direccion);
    fprintf(archivo, "------------------------------\n");
}

void cargarPacientes(struct Paciente pacientes[], int *numPacientes) {
    FILE *archivo = fopen("pacientes.txt", "r");
    if (archivo == NULL) {
        printf("No se encontró el archivo de pacientes.\n");
        return;
    }

    int id;
    char nombre[100];
    char direccion[100];

    while (fscanf(archivo, "ID: %d\n", &id) == 1) {
        fscanf(archivo, "Nombre: %[^\n]\n", nombre);
        fscanf(archivo, "Dirección: %[^\n]\n", direccion);
        fscanf(archivo, "------------------------------\n");

        struct Paciente paciente;
        paciente.id = id;
        strcpy(paciente.nombre, nombre);
        strcpy(paciente.direccion, direccion);

        pacientes[*numPacientes] = paciente;
        (*numPacientes)++;
    }

    fclose(archivo);
}

void guardarPacientes(struct Paciente pacientes[], int numPacientes) {
    FILE *archivo = fopen("pacientes.txt", "w");
    if (archivo == NULL) {
        printf("Error al abrir el archivo de pacientes.\n");
        return;
    }

    for (int i = 0; i < numPacientes; i++) {
        guardarPaciente(pacientes[i], archivo);
    }

    fclose(archivo);
}

void mostrarPacientes(struct Paciente pacientes[], int numPacientes) {
    if (numPacientes == 0) {
        printf("No se han encontrado pacientes.\n");
        return;
    }

    printf("----- PACIENTES -----\n");
    for (int i = 0; i < numPacientes; i++) {
        printf("ID: %d\n", pacientes[i].id);
        printf("Nombre: %s\n", pacientes[i].nombre);
        printf("Dirección: %s\n", pacientes[i].direccion);
        printf("------------------------------\n");
    }
}

int buscarPacientePorId(struct Paciente pacientes[], int numPacientes, int id) {
    for (int i = 0; i < numPacientes; i++) {
        if (pacientes[i].id == id) {
            return i;
        }
    }
    return -1;
}

void buscarPaciente(struct Paciente pacientes[], int numPacientes) {
    int id;
    printf("Ingrese el ID del paciente a buscar: ");
    scanf("%d", &id);

    int indice = buscarPacientePorId(pacientes, numPacientes, id);
    if (indice != -1) {
        printf("El paciente con ID %d existe.\n", id);
        printf("Nombre: %s\n", pacientes[indice].nombre);
        printf("Dirección: %s\n", pacientes[indice].direccion);
    } else {
        printf("No se encontró un paciente con ID %d.\n", id);
    }
}

void agregarPaciente(struct Paciente pacientes[], int *numPacientes) {
    if (*numPacientes >= MAX_PACIENTES) {
        printf("Se ha alcanzado el número máximo de pacientes.\n");
        return;
    }

    struct Paciente paciente;
    int esValida;
do {
    printf("Ingrese el ID del paciente: ");
    scanf("%d", &paciente.id);
    esValida = validarCedula(paciente.id);
    if (!esValida) {
      printf("ID INVALIDO !! \nIntente de nuevo !!\n");
    }
  } while (!esValida);
    printf("Ingrese el nombre del paciente: ");
    scanf(" %[^\n]", paciente.nombre);
    printf("Ingrese la dirección del paciente: ");
    scanf(" %[^\n]", paciente.direccion);
    int indice = buscarPacientePorId(pacientes, *numPacientes, paciente.id);
    if (indice != -1) {
        printf("Ya existe un paciente con el mismo ID.\n");
    } else {
        pacientes[*numPacientes] = paciente;
        (*numPacientes)++;
        printf("El paciente se ha agregado correctamente.\n");
    }
}

void modificarPacientePorId(struct Paciente pacientes[], int numPacientes) {
    int id;
        printf("Ingrese el ID del paciente a modificar: ");
        scanf("%d", &id);
    int indice = buscarPacientePorId(pacientes, numPacientes, id);
    if (indice != -1) {
        struct Paciente paciente = pacientes[indice];

        printf("Ingrese el nuevo nombre del paciente: ");
        scanf(" %[^\n]", paciente.nombre);
        printf("Ingrese la nueva dirección del paciente: ");
        scanf(" %[^\n]", paciente.direccion);

        pacientes[indice] = paciente; // Actualizar el arreglo de pacientes con los nuevos valores modificados

        printf("El paciente con ID %d se ha modificado correctamente.\n", id);
    } else {
        printf("No se encontró un paciente con ID %d.\n", id);
    }
}

void eliminarPacientePorId(struct Paciente pacientes[], int *numPacientes) {

    int id;
        printf("Ingrese el ID del paciente a eliminar: ");
        scanf("%d", &id);

    int indice = buscarPacientePorId(pacientes, *numPacientes, id);
    if (indice != -1) {
        // Mover los pacientes posteriores al paciente a eliminar hacia atrás en el arreglo
        for (int i = indice; i < *numPacientes - 1; i++) {
            pacientes[i] = pacientes[i + 1];
        }

        (*numPacientes)--; // Actualizar el número de pacientes

        printf("El paciente con ID %d se ha eliminado correctamente.\n", id);
    } else {
        printf("No se encontró un paciente con ID %d.\n", id);
    }
}
//VERIFICACION DE CEDULA 
int validarCedula(int cedula) {
  int suma = 0;
  int digito;
  int digitoVerificacion;
  int factor = 2;

  // Calcular el dígito de verificación
  digitoVerificacion = cedula % 10;

  // Calcular la suma de los dígitos
  cedula /= 10;
  while (cedula > 0) {
    digito = (cedula % 10) * factor;
    if (digito >= 10) {
      digito = (digito / 10) + (digito % 10);
    }
    suma += digito;
    factor = (factor == 2) ? 1 : 2;
    cedula /= 10;
  }

  // Calcular el dígito final
  int digitoFinal = (10 - (suma % 10)) % 10;

  return (digitoFinal == digitoVerificacion);
}
//HORA
void obtenerHoraActual( struct Cita citas [], char* timeString) {
    time_t currentTime;
    struct tm *timeInfo;

    // Obtener la hora actual
    time(&currentTime);
    timeInfo = localtime(&currentTime);

    // Formatear la hora en una cadena de caracteres
    strftime(timeString, 9, "%H:%M:%S", timeInfo);
}

void obtenerFechaActual(struct Cita citas [], char* dateString) {
    time_t currentTime;
    struct tm *timeInfo;

    // Obtener la hora actual
    time(&currentTime);
    timeInfo = localtime(&currentTime);

    // Formatear la fecha en una cadena de caracteres
    strftime(dateString, 11, "%Y/%m/%d", timeInfo);
}
