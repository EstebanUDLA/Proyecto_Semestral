#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "menu.h"


#define MAX_PACIENTES 200
#define MAX_MEDICOS 200

int main() {
    struct Paciente pacientes[MAX_PACIENTES];
    struct Medico medicos[MAX_MEDICOS];
    struct Cita citas[MAX_CITAS];

    int numPacientes = 0;
    int numMedicos = 0;
    int numCitas=0;
    
    int mIngresos=0,mPaciente,mDoctor,mInformacion,mCitas;
    int infoPaciente, infoMedico, infoCitas;
    int mPrincipal=0;
    cargarPacientes(pacientes, &numPacientes);
    cargarMedicos(medicos,&numMedicos);
    cargarCitasDesdeArchivo(citas,&numCitas);
    do{
        mPrincipal=menu();
        switch(mPrincipal){
            case 1:
            do{

                mIngresos=menu2();
                switch(mIngresos){
                case 1:
                do{
                    mPaciente=menuPacientes();
                     switch (mPaciente) {
                    case 1: 
                        agregarPaciente(pacientes, &numPacientes);
                        guardarPacientes(pacientes, numPacientes);
                    break;
                
                    case 2: 
                        modificarPacientePorId(pacientes,numPacientes);
                        guardarPacientes(pacientes, numPacientes);
                    break;
                
                    case 3: 
                        eliminarPacientePorId(pacientes,&numPacientes);
                        guardarPacientes(pacientes, numPacientes);
                    break;
                
                    case 4:
                    
                    printf("Regresando...\n");
                    break;
                     default:
                    printf("Opción inválida. Por favor, intente nuevamente.\n");
                    break;
                    }
                }while(mPaciente!=4);
                break;
                case 2:
                do{
                    mDoctor=menumedico();
                     switch (mDoctor) {
                    case 1: 
                        agregarMedico(medicos, &numMedicos);
                        guardarMedicos(medicos, numMedicos);
                    break;
                
                    case 2: 
                        modificarMedicoPorId(medicos,numMedicos);
                        guardarMedicos(medicos, numMedicos);
                    break;
                
                    case 3: 
                        eliminarMedicoPorId(medicos,&numMedicos);
                        guardarMedicos(medicos, numMedicos);
                    break;
                
                    case 4:
                    printf("Regresando...\n");
                    break;
                     default:
                    printf("Opción inválida. Por favor, intente nuevamente.\n");
                    break;
                    }
                }while(mDoctor!=4);
                break;
                case 3:
                break;
                default:
                printf("Opcion Incorrecta");
                break;
            }
            }while(mIngresos!=3);
            break;
            case 2:
            do{
            mCitas=menuCitas();
            switch(mCitas){
                case 1:
                
                    agregarCita(citas,&numCitas,pacientes,numPacientes,medicos,numMedicos);
                    guardarCitas(citas,numCitas,pacientes,numPacientes,medicos,numMedicos);
                    break;
                case 2:
                    
                    break;
                case 3:
                    eliminarCitas(citas,&numCitas);
                    guardarCitas(citas,numCitas,pacientes,numPacientes,medicos,numMedicos);
                    break;
                case 4:
                    break;
                default:
                    break;
            }

            
            }while(mCitas!=4);
            break;
            case 3:
                do{
                mInformacion=menuInformacion();
                    switch(mInformacion){
                        case 1:
                        do{

                            infoPaciente=menupacientes();
                            switch (infoPaciente)
                            {
                            case 1:
                                int id;
                                printf("Ingresar el numero de cedula del paciente: ");
                                scanf("%d",&id);
                                buscarPacientePorId(pacientes,numPacientes,id);
                                break;
                            case 2:
                                mostrarPacientes(pacientes,numPacientes);
                                break;
                            case 3:
                                printf("Regresando...\n");
                                break;
                            default:
                                printf("Opcion Incorrecta\n");
                                break;
                            }
                        }while(infoPaciente!=3);

                        break;
                        case 2:
                        do{
                            infoMedico=menuInformacionMedico();
                            switch (infoMedico)
                            {
                            case 1:
                                int id;
                                printf("Ingresar el numero de cedula del Medico: ");
                                scanf("%d",&id);
                                buscarMedicoPorId(medicos,numMedicos,id);
                                break;
                            case 2:
                                mostrarMedicos(medicos,numMedicos);
                                break;
                            case 3:
                                printf("Regresando...\n");
                                break;
                            default:
                                printf("Opcion Incorrecta\n");
                                break;
                            }
                        }while(infoMedico!=3);
                        break;
                        case 3:
                        do{
                        infoCitas=menuInformacionCITAS();
                        switch(infoCitas){
                            case 1:
                            int id;

                            printf("Ingrese el id del paciente que desea verificar: ");
                            scanf("%d",&id);
                            cargarMedicos(medicos,&numMedicos);
                            buscarCitas(citas,numCitas,pacientes,numPacientes,medicos,numMedicos,id);
                                break;
                            case 2:
                                cargarMedicos(medicos,&numMedicos);
                                //mostrarCitas(citas,numCitas,pacientes,numPacientes,medicos,numMedicos);
                                mostrarCitas("registro.txt");
                                break;
                            case 3:
                                break;
                            default:
                                break;
                        }
                        }while(infoCitas!=3);
                        break;
                        case 4:
                        printf("Regresando...\n");
                        break;
                        default:
                            printf("Ingrese una opcion correcta");
                            break;
                    }
                }while(mInformacion!=4);
            break;
            case 4:
            printf("Gracias por preferirnos");
            break;
            default:
            break;
        }
    }while(mPrincipal!=4);

    return 0;
}
