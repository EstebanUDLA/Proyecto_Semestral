#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MAX_PACIENTES 200
#define MAX_MEDICOS 200
#define MAX_CITAS 200
#define NUM_MESES 12
#define NUM_DIAS 31
#define NUM_HORAS 9

struct Paciente {
    int id;
    int edad;
    char nombre[100];
    char direccion[100];
};
struct Medico{
    int id;
    char nombre[100];
    char especialidad[100];
};

struct Cita {
    int idPaciente;
    int idMedico;
    char medico[50];
    char paciente[50];
    //char fecha[20];
    //char hora[10];
    char timeString[9]; // Para almacenar la hora en formato HH:MM:SS
    char dateString[11]; // Para almacenar la fecha en formato AAAA/MM/DD
    int mes;
    int dia;
    int hora;
};

void guardarPaciente(struct Paciente paciente, FILE *archivo);
void cargarPacientes(struct Paciente pacientes[], int *numPacientes);
void guardarPacientes(struct Paciente pacientes[], int numPacientes);
void mostrarPacientes(struct Paciente pacientes[], int numPacientes);
int buscarPacientePorId(struct Paciente pacientes[], int numPacientes, int id);
void buscarPaciente(struct Paciente pacientes[], int numPacientes);
void agregarPaciente(struct Paciente pacientes[], int *numPacientes);
int validarCedula(int id);
void modificarPacientePorId(struct Paciente pacientes[], int numPacientes);
void eliminarPacientePorId(struct Paciente pacientes[], int *numPacientes);

void guardarMedico(struct Medico medico, FILE *archivo);
void cargarMedicos(struct Medico medicos[], int *numMedicos);
void guardarMedicos(struct Medico medicos[], int numMedicos);
void mostrarMedicos(struct Medico medicos[], int numMedicos);
int buscarMedicoPorId(struct Medico medicos[], int numMedicos, int id);
void buscarMedicos(struct Medico medicos[], int numMedicos);
void agregarMedico(struct Medico medicos[], int *numMedicos);
void modificarMedicoPorId(struct Medico medicos[], int numMedicos);
void eliminarMedicoPorId(struct Medico medicos[], int *numMedicos);
void buscarMedicosPorEspecialidad(struct Medico medicos[], int numMedicos, char especialidad[]);

void agregarCita(struct Cita citas[], int* numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos);
int verificarMedicoPorEspecialidad(const char* especialidad, struct Medico medicos[], int numMedicos);
int verificarCitaExistente(int idMedico, const char *fecha, const char *hora, const struct Cita citas[], int numCitas);

//void guardarCitas(struct Cita citas[], int numCitas);
void guardarCitas(struct Cita citas[], int numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos);
void cargarCitasDesdeArchivo(struct Cita citas[], int* numCitas);
//void mostrarCitas(struct Cita citas[], int* numCitas);
void mostrarCitas(const char* registro) ;
void buscarCitas(struct Cita citas[], int numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos, int idPaciente);
void eliminarCitas(struct Cita citas[], int *numCitas);


//horas
void obtenerFechaActual(struct Cita citas [], char* dateString);
void obtenerHoraActual(struct Cita citas [], char* timeString);

//horas

void inicializarCalendario(struct Cita citas[NUM_MESES][NUM_DIAS][NUM_HORAS]);
void marcarHoraAlmuerzo(struct Cita citas[NUM_MESES][NUM_DIAS][NUM_HORAS]);
void solicitarCita(struct Cita citas[NUM_MESES][NUM_DIAS][NUM_HORAS]);
