#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"

void guardarMedico(struct Medico medico, FILE *archivo) {
    fprintf(archivo, "ID: %d\n", medico.id);
    fprintf(archivo, "Nombre: %s\n", medico.nombre);
    fprintf(archivo, "Especialidad: %s\n", medico.especialidad);
    fprintf(archivo, "------------------------------\n");
}

void cargarMedicos(struct Medico medicos[], int *numMedicos) {
    FILE *archivo = fopen("medicos.txt", "r");
    if (archivo == NULL) {
        printf("No se encontro el archivo de medicos.\n");
        return;
    }

    int id;
    char nombre[100];
    char especialidad[100];

    while (fscanf(archivo, "ID: %d\n", &id) == 1) {
        fscanf(archivo, "Nombre: %[^\n]\n", nombre);
        fscanf(archivo, "Especialidad: %[^\n]\n", especialidad);
        fscanf(archivo, "------------------------------\n");

        struct Medico medico;
        medico.id = id;
        strcpy(medico.nombre, nombre);
        strcpy(medico.especialidad, especialidad);

        medicos[*numMedicos] = medico;
        (*numMedicos)++;
    }

    fclose(archivo);
}

void guardarMedicos(struct Medico medicos[], int numMedicos) {
    FILE *archivo = fopen("medicos.txt", "w");
    if (archivo == NULL) {
        printf("Error al abrir el archivo de medicos.\n");
        return;
    }

    for (int i = 0; i < numMedicos; i++) {
        guardarMedico(medicos[i], archivo);
    }

    fclose(archivo);
}

void mostrarMedicos(struct Medico medicos[], int numMedicos) {
    if (numMedicos == 0) {
        printf("No se han encontrado medicos.\n");
        return;
    }

    printf("----- Medicos -----\n");
    for (int i = 0; i < numMedicos; i++) {
        printf("ID: %d\n", medicos[i].id);
        printf("Nombre: %s\n", medicos[i].nombre);
        printf("especialidad: %s\n", medicos[i].especialidad);
        printf("------------------------------\n");
    }
}


int buscarMedicoPorId(struct Medico medicos[], int numMedicos, int id) {
    for (int i = 0; i < numMedicos; i++) {
        if (medicos[i].id == id) {
            return i;
        }
    }
    return -1;
}

void buscarMedicos(struct Medico medicos[], int numMedicos) {
    int id;
    printf("Ingrese el ID del paciente a buscar: ");
    scanf("%d", &id);

    int indice = buscarMedicoPorId(medicos, numMedicos, id);
    if (indice != -1) {
        printf("El medico con ID %d existe.\n", id);
        printf("Nombre: %s\n", medicos[indice].nombre);
        printf("Especialidad: %s\n", medicos[indice].especialidad);
    } else {
        printf("No se encontro un medico con ID %d.\n", id);
    }
}

void agregarMedico(struct Medico medicos[], int *numMedicos) {
    if (*numMedicos >= MAX_PACIENTES) {
        printf("Se ha alcanzado el numero maximo de pacientes.\n");
        return;
    }

    struct Medico medico;
    int esValida;
do {
    printf("Ingrese el ID del medico: ");
    scanf("%d", &medico.id);
    esValida = validarCedula(medico.id);
    if (!esValida) {
      printf("ID INVALIDO !! \nIntente de nuevo !!\n");
    }
  } while (!esValida);
    printf("Ingrese el nombre del medico: ");
    scanf(" %[^\n]", medico.nombre);
    printf("Ingrese la especialidad del medico: ");
    scanf(" %[^\n]", medico.especialidad);

    int indice = buscarMedicoPorId(medicos, *numMedicos, medico.id);
    if (indice != -1) {
        printf("Ya existe un medico con el mismo ID.\n");
    } else {
        medicos[*numMedicos] = medico;
        (*numMedicos)++;
        printf("El medico se ha agregado correctamente.\n");
    }
}

void modificarMedicoPorId(struct Medico medicos[], int numMedicos) {
    int id;
        printf("Ingrese el ID del medico a modificar: ");
        scanf("%d", &id);
    int indice = buscarMedicoPorId(medicos, numMedicos, id);
    if (indice != -1) {
        struct Medico medico = medicos[indice];

        printf("Ingrese el nombre del medico: ");
        scanf(" %[^\n]", medico.nombre);
        printf("Ingrese la especialidad del paciente: ");
        scanf(" %[^\n]", medico.especialidad);

        medicos[indice] = medico; // Actualizar el arreglo de medicos con los nuevos valores modificados

        printf("El medico con ID %d se ha modificado correctamente.\n", id);
    } else {
        printf("No se encontro un medico con ID %d.\n", id);
    }
}

void eliminarMedicoPorId(struct Medico medicos[], int *numMedicos) {

    int id;
        printf("Ingrese el ID del medico a eliminar: ");
        scanf("%d", &id);

    int indice = buscarMedicoPorId(medicos, *numMedicos, id);
    if (indice != -1) {
        // Mover los medicos posteriores al paciente a eliminar hacia atrás en el arreglo
        for (int i = indice; i < *numMedicos - 1; i++) {
            medicos[i] = medicos[i + 1];
        }

        (*numMedicos)--; // Actualizar el número de pacientes

        printf("El medico con ID %d se ha eliminado correctamente.\n", id);
    } else {
        printf("No se encontro un medico con ID %d.\n", id);
    }
}

void buscarMedicosPorEspecialidad(struct Medico medicos[], int numMedicos, char especialidad[]) {
    printf("Medicos disponibles en la especialidad '%s':\n", especialidad);
    
    int contador = 0;
    
    for (int i = 0; i < numMedicos; i++) {
        if (strcmp(medicos[i].especialidad, especialidad) == 0) {
            printf("- ID: %d, Nombre: %s\n", medicos[i].id, medicos[i].nombre);
            contador++;
        }
    }
    
    if (contador == 0) {
        printf("No se encontraron medicos en la especialidad '%s'.\n", especialidad);
    }
}

int verificarMedicoPorEspecialidad(const char* especialidad, struct Medico medicos[], int numMedicos) {
    for (int i = 0; i < numMedicos; i++) {
        if (strcmp(medicos[i].especialidad, especialidad) == 0) {
            return i;  // Se encontró un médico con la especialidad
        }
    }
    
    return -1;  // No se encontró ningún médico con la especialidad
}