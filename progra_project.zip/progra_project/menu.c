#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int menu(){
    int valor;

    printf("\n");
    printf("Bienvenido al programa\n");
    printf("\n");
    printf("1. Ingresos \n");
    printf("2. Citas\n");
    printf("3. Informacion\n");
    printf("4. Salir\n");
    printf("\n Ingrese la opcion que desea: ");
    scanf("%d",&valor);
    return valor;
}
int menu2(){
    int valor;
    printf("\n");
    printf("1. Pacientes \n");
    printf("2. Doctores\n");
    printf("3. Salir\n");
    printf("Ingrese una opcion: ");
    scanf("%d",&valor);
    return valor;
}

int menuPacientes(){
    int valor;

    printf("\n");
    printf("1. Ingreso Paciente \n");
    printf("2. Modificacion Pacientes\n");
    printf("3. Eliminar Paciente\n");
    printf("4. Regresar\n");
    printf("\n Ingrese la opcion que desea: ");
    scanf("%d",&valor);
    return valor;
}
int menumedico(){
    int valor;

    printf("\n");
    printf("1. Ingreso Medico \n");
    printf("2. Modificacion Medico\n");
    printf("3. Eliminar Medico\n");
    printf("4. Regresar\n");
    printf("\n Ingrese la opcion que desea: ");
    scanf("%d",&valor);
    return valor;
}


int menuIngresos(){
int valor;

    printf("\n");
    printf("1. Ingreso Paciente \n");
    printf("2. Ingreso Doctores\n");
    printf("3. Salir\n");
    scanf("%d",&valor);
    return valor;
}

int menuCitas(){
int valor;

    printf("\n");
    printf("1. Registro de citas \n");
    printf("2. Modificacion de citas\n");
    printf("3. Eliminar citas\n");
    printf("4. Regresar\n");
    printf("\n Ingrese la opcion que desea: ");
    scanf("%d",&valor);
    return valor;
}

int menuInformacion(){
int valor;

  printf("INFORMACION\n");
  printf("1.Pacientes\n");
  printf("2.Medicos\n");
  printf("3.Citas\n");
  printf("4. Regresar\n");
  printf("Ingrese la opcion que desea: ");
    scanf("%d",&valor);
    return valor;
}


int menupacientes(){
int valor;
printf("PACIENTES\n");
printf("1. Buscar paciente\n");
printf("2. Mostrar paciententes registrados\n");
printf("3.Regresar\n");
printf("Ingrese una opcion: ");
    scanf("%d",&valor);
    return valor;
}
int menuInformacionMedico(){
int valor;
printf("MEDICOS\n");
printf("1. Buscar Medico\n");
printf("2. Mostrar Medicos registrados\n");
printf("3.Regresar\n");

    scanf("%d",&valor);
    return valor;
}
int menuInformacionCITAS(){
int valor;
printf("INFORMACION CITAS\n");
printf("1.Buscar Cita\n");
printf("2.Mostrar Citas\n");
printf("3.Salir\n");
printf("Ingres ela opcion que desea: ");
scanf("%d",&valor);
return valor;
}