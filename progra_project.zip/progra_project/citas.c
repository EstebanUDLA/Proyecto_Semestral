#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "funciones.h"

// Función para agregar una nueva cita
void cargarCitasDesdeArchivo(struct Cita citas[], int* numCitas) {
    FILE* archivo = fopen("registro.txt", "r");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para leer. Se asume que no hay citas previas.\n");
        return;
    }

    *numCitas = 0;
    char linea[100];

    while (fgets(linea, sizeof(linea), archivo) != NULL) {
        if (strncmp(linea, "Cita", 4) == 0) {
            struct Cita nuevaCita;
            fscanf(archivo, "ID Paciente: %d\n", &nuevaCita.idPaciente);
            fscanf(archivo, "ID Médico: %d\n", &nuevaCita.idMedico);
            citas[*numCitas] = nuevaCita;
            (*numCitas)++;
        }
    }

    fclose(archivo);
    printf("Se cargaron %d citas desde el archivo 'citas.txt'.\n", *numCitas);
}

/*void guardarCitas(struct Cita citas[], int numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos) {
    FILE* archivo = fopen("registro.txt", "w");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para escribir.\n");
        return;
    }
    // Obtener la hora y fecha actual para cada cita
    for (int i = 0; i < numCitas; i++) {
        obtenerHoraActual(citas[i].timeString);
        obtenerFechaActual(citas[i].dateString);
    }

    // Imprimir las horas y fechas de las citas
    for (int i = 0; i < numCitas; i++) {
        printf("Cita %d:\n", i + 1);
        printf("Hora: %s\n", citas[i].timeString);
        printf("Fecha: %s\n", citas[i].dateString);
        printf("\n");
    }
    for (int i = 0; i < numCitas; i++) {
        fprintf(archivo, "Cita %d:\n", i + 1);
        int indicePaciente = buscarPacientePorId(pacientes, numPacientes, citas[i].idPaciente);
        if (indicePaciente != -1) {

            fprintf(archivo, "ID Paciente: %d\n", citas[i].idPaciente);
            fprintf(archivo, "Nombre Paciente: %s\n", pacientes[indicePaciente].nombre);
        }

        int indiceMedico = buscarMedicoPorId(medicos, numMedicos, citas[i].idMedico);
        if (indiceMedico != -1) {
            fprintf(archivo, "ID Medico: %d\n", citas[i].idMedico);
            fprintf(archivo, "Nombre Medico: %s\n", medicos[indiceMedico].nombre);
            fprintf(archivo, "Especialidad Medico: %s\n", medicos[indiceMedico].especialidad);
        }

        fprintf(archivo, "\n");
    }

    fclose(archivo);
    printf("Los datos de las citas se han guardado en el archivo 'citas.txt'.\n");
}*/
void guardarCitas(struct Cita citas[], int numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos) {
    FILE* archivo = fopen("registro.txt", "w");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para escribir.\n");
        return;
    }

    for (int i = 0; i < numCitas; i++) {
        fprintf(archivo, "Cita %d:\n", i + 1);
        int indicePaciente = buscarPacientePorId(pacientes, numPacientes, citas[i].idPaciente);
        if (indicePaciente != -1) {
            obtenerHoraActual(citas, citas[i].timeString);
            obtenerFechaActual(citas,citas[i].dateString);
            fprintf(archivo, "Hora %s y Fecha %s de ingreso de cita\n", citas[i].timeString, citas[i].dateString);
            fprintf(archivo, "ID Paciente: %d\n", citas[i].idPaciente);
            fprintf(archivo, "Nombre Paciente: %s\n", pacientes[indicePaciente].nombre);
        }

        int indiceMedico = buscarMedicoPorId(medicos, numMedicos, citas[i].idMedico);
        if (indiceMedico != -1) {
            fprintf(archivo, "ID Medico: %d\n", citas[i].idMedico);
            fprintf(archivo, "Nombre Medico: %s\n", medicos[indiceMedico].nombre);
            fprintf(archivo, "Especialidad Medico: %s\n", medicos[indiceMedico].especialidad);
            fprintf(archivo, "FECHA DE LA CITA\n" );
            fprintf(archivo, "Mes: %d\n", citas[i].mes);
            fprintf(archivo, "Dia: %d\n", citas[i].dia);
            fprintf(archivo, "Hora: %d\n", citas[i].hora);
        }

        fprintf(archivo, "\n");
    }

    fclose(archivo);
    printf("Los datos de las citas se han guardado en el archivo 'registro.txt'.\n");
}

void agregarCita(struct Cita citas[], int* numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos) {
    if (*numCitas >= MAX_CITAS) {
        printf("No se pueden agregar mas citas. Se ha alcanzado el límite máximo.\n");
        return;
    }

    struct Cita nuevaCita;

    printf("Ingrese el ID del paciente: ");
    scanf("%d", &nuevaCita.idPaciente);

    // Verificar si el paciente existe
    int indicePaciente = buscarPacientePorId(pacientes, numPacientes, nuevaCita.idPaciente);
    if (indicePaciente == -1) {
        printf("El paciente con ID %d no existe. No se puede agregar la cita.\n", nuevaCita.idPaciente);
        return;
    }

    char especialidad[50];
    printf("Ingrese la especialidad del medico: ");
    scanf("%s", especialidad);

    // Verificar si hay médicos disponibles para la especialidad dada
    int indiceMedico = verificarMedicoPorEspecialidad(especialidad, medicos, numMedicos);
    if (indiceMedico == -1) {
        printf("No hay medicos disponibles para la especialidad '%s'. No se puede agregar la cita.\n", especialidad);
        return;
    }

    printf("Medicos disponibles para la especialidad '%s':\n", especialidad);
    int contador = 0;
    for (int i = 0; i < numMedicos; i++) {
        if (strcmp(medicos[i].especialidad, especialidad) == 0) {
            printf("- ID: %d, Nombre: %s, Especialidad: %s\n", medicos[i].id, medicos[i].nombre, medicos[i].especialidad);
            contador++;
        }
    }

    if (contador == 0) {
        printf("No hay medicos disponibles para la especialidad '%s'. No se puede agregar la cita.\n", especialidad);
        return;
    }

    printf("Ingrese el ID del medico seleccionado: ");
    scanf("%d", &nuevaCita.idMedico);

    // Verificar si el médico existe
    int indiceMedicoSeleccionado = -1;
    for (int i = 0; i < numMedicos; i++) {
        if (medicos[i].id == nuevaCita.idMedico) {
            indiceMedicoSeleccionado = i;
            break;
        }
    }

    if (indiceMedicoSeleccionado == -1) {
        printf("El medico con ID %d no existe. No se puede agregar la cita.\n", nuevaCita.idMedico);
        return;
    }

    strcpy(nuevaCita.medico, medicos[indiceMedicoSeleccionado].nombre);

    printf("Ingrese el mes de la cita (1-12): ");
    scanf("%d", &nuevaCita.mes);
    printf("Ingrese el dia de la cita (1-31): ");
    scanf("%d", &nuevaCita.dia);
    printf("Ingrese la hora de la cita (9-17): ");
    scanf("%d", &nuevaCita.hora);

    // Agregar la cita al arreglo de citas
    citas[*numCitas] = nuevaCita;
    (*numCitas)++;

    printf("Cita agregada con exito.\n");
}

/*void agregarCita(struct Cita citas[], int* numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos) {
    if (*numCitas >= MAX_CITAS) {
        printf("No se pueden agregar mas citas. Se ha alcanzado el limite maximo.\n");
        return;
    }

    struct Cita nuevaCita;

    printf("Ingrese el ID del paciente: ");
    scanf("%d", &nuevaCita.idPaciente);

    // Verificar si el paciente existe
    int indicePaciente = buscarPacientePorId(pacientes, numPacientes, nuevaCita.idPaciente);
    if (indicePaciente == -1) {
        printf("El paciente con ID %d no existe. No se puede agregar la cita.\n", nuevaCita.idPaciente);
        return;
    }

    char especialidad[50];
    char nombre[50];
    printf("Ingrese la especialidad del médico: ");
    scanf("%s", especialidad);

    // Verificar si hay médicos disponibles para la especialidad dada
    int indiceMedico = verificarMedicoPorEspecialidad(especialidad, medicos, numMedicos);
    if (indiceMedico == -1) {
        printf("No hay medicos disponibles para la especialidad '%s'. No se puede agregar la cita.\n", especialidad);
        return;
    }

    printf("Medicos disponibles para la especialidad '%s':\n", especialidad);
    int contador = 0;
    for (int i = 0; i < numMedicos; i++) {
        if (strcmp(medicos[i].especialidad, especialidad) == 0) {
            printf("- ID: %d, Nombre: %s, Especialidad: %s\n", medicos[i].id, medicos[i].nombre, medicos[i].especialidad);
            contador++;
        }
    }

    if (contador == 0) {
        printf("No hay medicos disponibles para la especialidad '%s'. No se puede agregar la cita.\n", especialidad);
        return;
    }

    printf("Ingrese el ID del médico seleccionado: ");
    scanf("%d", &nuevaCita.idMedico);

    // Verificar si el médico existe
    int indiceMedicoSeleccionado = -1;
    for (int i = 0; i < numMedicos; i++) {
        if (medicos[i].id == nuevaCita.idMedico) {
            indiceMedicoSeleccionado = i;
            break;
        }
    }

    if (indiceMedicoSeleccionado == -1) {
        printf("El medico con ID %d no existe. No se puede agregar la cita.\n", nuevaCita.idMedico);
        return;
    }

    strcpy(nuevaCita.medico, medicos[indiceMedicoSeleccionado].nombre);

    // Agregar la cita al arreglo de citas
    citas[*numCitas] = nuevaCita;
    (*numCitas)++;
    int mes, dia, hora;
    printf("Ingrese el mes de la cita (1-12): ");
    scanf("%d", &mes);
    printf("Ingrese el día de la cita (1-31): ");
    scanf("%d", &dia);
    printf("Ingrese la hora de la cita (9-17): ");
    scanf("%d", &hora);
    citas[0].mes = mes;
    citas[0].dia = dia;
    citas[0].hora = hora;
    printf("Cita agregada con exito.\n");
}*/

/*int verificarCitaExistente(int idMedico, const char *fecha, const char *hora, const struct Cita citas[], int numCitas) {

    for (int i = 0; i < numCitas; i++) {
        if (idMedico == citas[i].idMedico && strcmp(fecha, citas[i].fecha) == 0 && strcmp(hora, citas[i].hora) == 0) {
            return 1; // Cita existente
        }
    }
    return 0; // Cita no existente
}*/

void mostrarCitas(const char* registro) {
    FILE* archivo = fopen(registro, "r");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }

    char linea[100];
    while (fgets(linea, sizeof(linea), archivo) != NULL) {
        printf("%s", linea);
    }

    fclose(archivo);
}


void buscarCitas(struct Cita citas[], int numCitas, struct Paciente pacientes[], int numPacientes, struct Medico medicos[], int numMedicos, int idPaciente) {
    printf("----- CITAS DEL PACIENTE -----\n");
    int citasEncontradas = 0;
    
    for (int i = 0; i < numCitas; i++) {
        if (citas[i].idPaciente == idPaciente) {
            citasEncontradas++;
            
            printf("Cita %d:\n", citasEncontradas);
            printf("ID Paciente: %d\n", citas[i].idPaciente);

            // Buscar el nombre del paciente correspondiente al ID
            for (int j = 0; j < numPacientes; j++) {
                if (pacientes[j].id == idPaciente) {
                    printf("Nombre Paciente: %s\n", pacientes[j].nombre);
                    break;
                }
            }

            int idMedico = citas[i].idMedico;
            printf("Nombre Medico: ");

            // Buscar el nombre del médico correspondiente al ID
            for (int j = 0; j < numMedicos; j++) {
                if (medicos[j].id == idMedico) {
                    printf("%s\n", medicos[j].nombre);
                    break;
                }
            }

            printf("------------------------------\n");
        }
    }

    if (citasEncontradas == 0) {
        printf("No se encontraron citas para el paciente con ID: %d\n", idPaciente);
    }
}

void eliminarCitas(struct Cita citas[], int *numCitas) {
    int citasEliminadas = 0;
    int id;
    printf("Ingrese el Id del paciente con cita registrada a eliminar: ");
    scanf("%d",&id);

    
    for (int i = 0; i < *numCitas; i++) {
        if (citas[i].idPaciente == id) {
            // Mover la última cita al lugar de la cita actual
            citas[i] = citas[*numCitas - 1];
            (*numCitas)--;
            citasEliminadas++;
            
            // Volver a verificar la cita actual en el próximo ciclo
            i--;
        }
    }
    
    printf("Se eliminaron %d citas del paciente con ID: %d\n", citasEliminadas, id);
}
//FECHA Y HORA DE CITAS
void inicializarCalendario(struct Cita citas[NUM_MESES][NUM_DIAS][NUM_HORAS]) {
    int i, j, k;
    
    for (i = 0; i < NUM_MESES; i++) {
        for (j = 0; j < NUM_DIAS; j++) {
            for (k = 0; k < NUM_HORAS; k++) {
                citas[i][j][k].mes = i + 1;
                citas[i][j][k].dia = j + 1;
                citas[i][j][k].hora = k + 9;
            }
        }
    }
}

void marcarHoraAlmuerzo(struct Cita citas[NUM_MESES][NUM_DIAS][NUM_HORAS]) {
    int i, j;
    
    for (i = 0; i < NUM_MESES; i++) {
        for (j = 0; j < NUM_DIAS; j++) {
            citas[i][j][4].hora = -1; // Marcar la hora de almuerzo como no disponible (-1)
        }
    }
}

void solicitarCita(struct Cita citas[NUM_MESES][NUM_DIAS][NUM_HORAS]) {
    int mes, dia, hora;
    
    printf("Ingrese el mes de la cita (1-12): ");
    scanf("%d", &mes);
    printf("Ingrese el día de la cita (1-31): ");
    scanf("%d", &dia);
    printf("Ingrese la hora de la cita (9-17): ");
    scanf("%d", &hora);
    
    if (citas[mes - 1][dia - 1][hora - 9].hora != -1) {
        if (hora == 13) {
            printf("\n¡Es la hora del almuerzo!\n");
        }
        
        printf("\nLa cita médica está disponible:\n");
        printf("Fecha: %02d/%02d\n", dia, mes);
        printf("Hora: %d\n", hora);
    } else {
        printf("La cita para esa fecha y hora no está disponible. Por favor, elija otra fecha u hora.\n");
    }
}