#include <stdlib.h>
#include <stdio.h>

int menu();
int menuIngresos();
int menuCitas();
int menuInformacion();
int menuPacientes();
int menu2();
int menumedico();
int menupacientes();
int menuInformacionMedico();
int menuInformacionCITAS();